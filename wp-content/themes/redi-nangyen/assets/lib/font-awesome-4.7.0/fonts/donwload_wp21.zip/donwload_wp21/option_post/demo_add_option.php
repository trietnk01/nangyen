<?php 
/*

Add demo option page/post

* Change lại func setup metabox:

- change tilte
- change func CALL BACK


* function call back metabox
- change wp_once_field


* Add field

- change html, css, js ỡ function


*/

// Add img background of template background
function ptheme_show_title_add_metabox () {
	add_meta_box( 
		'ptheme_show_title_add_metabox', // id
		 __( 'Thiết lập tiêu đề', 'ptheme' ), // title 
		 'ptheme_show_title_option_metabox', // func callback 
		 array('post','page') ,  // custom post type
		 'side',  // where
		 'low' // where
	);
}


add_action( 'save_post', 'ptheme_show_title_save_post');
function ptheme_show_title_save_post ( $post_id ) {

	// Ko cho tự động autosave
	if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

	// Nếu không phải post,page thì return
	 if ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {
        return;
    }

    // Nếu không có biến nonce thì return
	if( !isset( $_POST['ptheme_show_title_nonce_name'] ) || !wp_verify_nonce( $_POST['ptheme_show_title_nonce_name'], 'ptheme_show_title_nonce_action' ) ) return;


	$show_title = isset( $_POST['show_title'] ) ? $_POST['show_title']  : "show";
	$align_title = isset( $_POST['align_title'] ) ? $_POST['align_title']  : "left";

	update_post_meta( $post_id, 'show_title', $show_title );
	update_post_meta( $post_id, 'align_title', $align_title );


} 

add_action( 'add_meta_boxes', 'ptheme_show_title_add_metabox' );
function ptheme_show_title_option_metabox () {
		wp_nonce_field( 'ptheme_show_title_nonce_action', 'ptheme_show_title_nonce_name' );
	?>
	<?php 
		global $post;
		
		$show_title = get_post_meta( $post->ID, 'show_title',  true ) ? get_post_meta( $post->ID, 'show_title',  true ) : "";
		$align_title = get_post_meta( $post->ID, 'align_title',  true ) ? get_post_meta( $post->ID, 'align_title',  true ) : "";

	?>

	<div>
		<p>
			<b><?php _e("Hiện tiêu đề hay không ? ","ptheme") ?></b>
		</p>

		<p>
			<input type="radio" name="show_title" value="show" id="show_title1" <?php checked( $show_title ,"show") ?>> <label for="show_title1"><?php _e("Hiện","ptheme");?></label>
		</p>

		<p>
			<input type="radio" name="show_title" value="no" id="show_title2" <?php checked( $show_title ,"no") ?>> <label for="show_title2"><?php _e("Không","ptheme")?></label>
		</p>
	</div>

	

	<div class="show_align_title <?php if( $show_title == "" || $show_title == "no" ) { echo "hidden"; } ?>">
		<p>
			<b><?php _e("Vị trí tiêu đề ?","ptheme") ?></b>
		</p>

		<p>
			<input type="radio" name="align_title" value="left" id="align_title1" <?php if( $align_title ) { checked( $align_title ,"left"); } else { echo "checked"; }  ?> > <label for="align_title1"><?php _e("Trái","ptheme");?></label>
		</p>

		<p>
			<input type="radio" name="align_title" value="center" id="align_title2" <?php checked( $align_title ,"center") ?>> <label for="align_title2"><?php _e("Giữa","ptheme")?></label>
		</p>

		<p>
			<input type="radio" name="align_title" value="right" id="align_title3" <?php checked( $align_title ,"right") ?>> <label for="align_title3"><?php _e("Phải","ptheme")?></label>
		</p>
	</div>



	<script type="text/javascript">
		 jQuery(function($) {
		 	 // function click radio show class
		 	 function ptheme_meta_box_show_class(name, class_show){
		 	 	if ( $(name).val() == "show" ) {
		 	 		$(class_show).show();
		 	 	} else {
		 	 		$(class_show).hide();
		 	 	}
		 	 }

		 	 $('[name="show_title"]').change(function(){
		 	 	ptheme_meta_box_show_class(this, '.show_align_title' );
		 	 })

		 });
	</script>

	<?php
}




