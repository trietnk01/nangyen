(function(){
    tinymce.PluginManager.add('mybutton_click',function( editor, url ){

        editor.addButton( "mybutton_click", {
            text: '</hr>',
            image : tinyMCE_mybutton_click.image_url ,
            tooltip: tinyMCE_mybutton_click.tooltip,
            onclick: function(){
                var shortcode = "[shortcode_mybutton_click]";
                window.parent.send_to_editor(shortcode);
                window.parent.tb_remove();
            },
        });
    });
})();
