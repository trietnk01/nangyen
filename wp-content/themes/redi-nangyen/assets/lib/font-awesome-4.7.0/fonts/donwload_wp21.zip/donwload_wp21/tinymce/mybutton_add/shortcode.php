<?php
add_shortcode( 'shortcode_mybutton_add' , 'shortcode_mybutton_add' );

function shortcode_mybutton_add($atts){
		ob_start();
	?>

	<div class="row">

		<?php if( $atts['blogname'] && $atts['blogname'] != "" ) { ?>

			<div class="col-xs-12 col-sm-6 p-mb-20">
				Họ tên:
			</div>

			<div class="col-xs-12 col-sm-6">
				<?php echo $atts['blogname']; ?>
			</div>

		 <?php } ?>


		<?php if( $atts['blogemail'] && $atts['blogemail'] != "" ) { ?>

			<div class="col-xs-12 col-sm-6 p-mb-20">
				Email:
			</div>

			<div class="col-xs-12 col-sm-6">
				<?php echo $atts['blogemail']; ?>
			</div>

		 <?php } ?>



		<?php if( $atts['blogphone'] && $atts['blogphone'] != "" ) { ?>

			<div class="col-xs-12 col-sm-6 p-mb-20">
				Phone:
			</div>

			<div class="col-xs-12 col-sm-6">
				<?php echo $atts['blogphone']; ?>
			</div>

		 <?php } ?>


	</div>


	<?php 
		return ob_get_clean();
}	



