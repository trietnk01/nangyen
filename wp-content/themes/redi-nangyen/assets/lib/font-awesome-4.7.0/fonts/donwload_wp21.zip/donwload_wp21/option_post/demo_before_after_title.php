<?php 
/*

show before after text of title

*/ 

// Add img background of template background
function ptheme_before_after_text_add_metabox () {
	add_meta_box( 
		'ptheme_before_after_text_add_metabox', // id
		 __( 'Thiết lập tiêu đề', 'ptheme' ), // title 
		 'ptheme_before_after_text_option_metabox', // func callback 
		 array('post','page', 'product') ,  // custom post type
		 'side',  // where
		 'low' // where
	);
}


add_action( 'save_post', 'ptheme_before_after_text_save_post');
function ptheme_before_after_text_save_post ( $post_id ) {

	// Ko cho tự động autosave
	if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

	// Nếu không phải post,page thì return
	 if ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {
        return;
    }

    // Nếu không có biến nonce thì return
	if( !isset( $_POST['ptheme_before_after_text_nonce_name'] ) || !wp_verify_nonce( $_POST['ptheme_before_after_text_nonce_name'], 'ptheme_before_after_text_nonce_action' ) ) return;

	$show_after_before_text = isset( $_POST['show_after_before_text'] ) ? $_POST['show_after_before_text']  : "no";
	$align_before_after_text = isset( $_POST['align_before_after_text'] ) ? $_POST['align_before_after_text']  : "left";
	$text_before_after_text = isset( $_POST['text_before_after_text'] ) ? $_POST['text_before_after_text']  : "";

	update_post_meta( $post_id, 'show_after_before_text', $show_after_before_text );
	update_post_meta( $post_id, 'align_before_after_text', $align_before_after_text );
	update_post_meta( $post_id, 'text_before_after_text', $text_before_after_text );

} 

add_action( 'add_meta_boxes', 'ptheme_before_after_text_add_metabox' );
function ptheme_before_after_text_option_metabox () {
		wp_nonce_field( 'ptheme_before_after_text_nonce_action', 'ptheme_before_after_text_nonce_name' );
	?>
	<?php 
		global $post;
		
		$show_after_before_text = get_post_meta( $post->ID, 'show_after_before_text',  true ) ? get_post_meta( $post->ID, 'show_after_before_text',  true ) : "";
		$align_before_after_text = get_post_meta( $post->ID, 'align_before_after_text',  true ) ? get_post_meta( $post->ID, 'align_before_after_text',  true ) : "";
		$text_before_after_text = get_post_meta( $post->ID, 'text_before_after_text',  true ) ? get_post_meta( $post->ID, 'text_before_after_text',  true ) : "";
	?>

	<div>
		<p>
			<b><?php _e("Hiện nội dung phụ tiêu đề hay không ? ","ptheme") ?></b>
		</p>

		<p>
			<input type="radio" name="show_after_before_text" value="show" id="show_after_before_text1" <?php checked( $show_after_before_text ,"show") ?>> <label for="show_after_before_text1"><?php _e("Hiện","ptheme");?></label>
		</p>

		<p>
			<input type="radio" name="show_after_before_text" value="no" id="show_after_before_text2" <?php checked( $show_after_before_text ,"no") ?>> <label for="show_after_before_text2"><?php _e("Không","ptheme")?></label>
		</p>
	</div>

	

	<div class="show_align_before_after_text <?php if( $show_after_before_text == "" || $show_after_before_text == "no" ) { echo "hidden"; } ?>">

		<div>
			<p>
				<b><?php _e("Vị trí nội dung phụ tiêu đề ?","ptheme") ?></b>
			</p>

			<p>
				<input type="radio" name="align_before_after_text" value="left" id="align_before_after_text1" <?php if( $align_before_after_text ) { checked( $align_before_after_text ,"left"); } else { echo "checked"; }  ?> > <label for="align_before_after_text1"><?php _e("Trước tiêu đề","ptheme");?></label>
			</p>


			<p>
				<input type="radio" name="align_before_after_text" value="right" id="align_before_after_text3" <?php checked( $align_before_after_text ,"right") ?>> <label for="align_before_after_text3"><?php _e("Sau tiêu đề","ptheme")?></label>
			</p>
		</div>

		

		<div>
			<p>
				<b><label><?php _e("Nội dung phụ: ","ptheme") ?></label></b>
			</p>

			<p>
				<a href="#TB_inline?width=10000&height=1000&inlineId=thickbox_before_aftet_text" class="thickbox button" id="thickbox_before_aftet_text_click"><i class="fa fa-adjust"> </i> <?php _e("Thêm icon ","ptheme") ?></a>   
			</p>
			<p>
				<input type="text" value="<?php echo htmlentities($text_before_after_text, ENT_QUOTES, "UTF-8") ?>" name="text_before_after_text" id="text_before_after_text" style="width:100%">
			</p>

		</div>

	</div>


	<!-- ** id class -->

	<style>
		.div-fafa-show{
			text-align: center;
			margin: 50px 0px 100px 0px;
		}

		.div-fafa-show>div{
			display: inline-block;
			width: 50px;
			height: 50px;
			line-height: 50px;
			text-align: center;
			border:1px solid #ccc;
			margin:2px;
			cursor: pointer;
			font-size: 20px;
		}


		.div-fafa-show>div:hover{
			background: #fafafa;
		}

		.div-fafa-show>div.active{
			border-color: #008ec2;
			background: #ccc;
		}

		.button_before_after_text{
			padding:10px !important;
			font-size: 15px !important;
			display: inline-block !important;
			width: 100% !important;
			height: 50px !important;
		}

		#TB_window{
			overflow: hidden !important;
		}

		#TB_ajaxContent{
			width: 100% !important;
			height: 100% !important;
			box-sizing: border-box !important;
		}
	</style>
	

	<div id="thickbox_before_aftet_text" style="display:none;width:100%;height:100%">

	    <div style="width:100%;height:100%">

	    	 <p class="submit" style="text-align:center">
	        	<input type="button" class="button button-primary button_before_after_text" value="<?php _e("SUBMIT","ptheme")?>">
	        </p>

	        <div class="div-fafa-show">
		        <?php include "fa-icon.php"; ?>
	    	</div>
	        <!-- * class submit -->

	       

	    </div>

	</div>



	<script type="text/javascript">
		 jQuery(function($) {
		 	 // function click radio show class
		 	 function ptheme_meta_box_show_class(name, class_show){
		 	 	if ( $(name).val() == "show" ) {
		 	 		$(class_show).show();
		 	 	} else {
		 	 		$(class_show).hide();
		 	 	}
		 	 }

		 	 $('[name="show_after_before_text"]').change(function(){
		 	 	ptheme_meta_box_show_class(this, '.show_align_before_after_text' );
		 	 })

		 	 var before_after_text = "";
		 	 $('.div-fafa-show>div').click(function(){
		 	 	$('.div-fafa-show>div.active').removeClass('active');
		 	 	 $(this).addClass('active');
		 	 	 before_after_text = $(this).html();
		 	 })

		 	 $('.button_before_after_text').click(function(){
		 	 	if( before_after_text  == "") { return; }
		 	 	var text_before = $('#text_before_after_text').val();

		 	 	$('#text_before_after_text').val( text_before + before_after_text );
		 	 	$('#TB_overlay').click();
		 	 })


		 })

	</script>

	<?php
}





