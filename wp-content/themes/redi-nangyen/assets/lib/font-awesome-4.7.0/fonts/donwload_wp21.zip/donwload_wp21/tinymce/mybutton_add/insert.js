jQuery(function($) {
    tinymce.PluginManager.add('mybutton_add',function( editor, url ){

        editor.addButton( "mybutton_add", {
            text: '<Add>',
            image : tinyMCE_mybutton_add.image_url ,
            tooltip: tinyMCE_mybutton_add.tooltip,
            onclick: function(){
                $('#mybutton_add_thickbox').click(); // target link thickbox
                // var shortcode = "[shortcode_mybutton_add]";
                //window.parent.send_to_editor(shortcode);
                //window.parent.tb_remove();
            },
        });
    });
})

