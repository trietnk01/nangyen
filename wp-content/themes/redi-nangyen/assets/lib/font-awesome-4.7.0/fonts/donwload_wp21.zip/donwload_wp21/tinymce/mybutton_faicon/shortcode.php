<?php
add_shortcode( 'shortcode_mybutton_faicon' , 'shortcode_mybutton_faicon' );

function shortcode_mybutton_faicon($atts){
		ob_start();
	?>
	<?php if( isset($atts['class']) && $atts['class'] != "" )  { ?>

	<i class="<?php echo $atts['class']  ?>"></i>
	
	<?php }  ?>

	<?php 
		return ob_get_clean();
}	



