<div id="post-<?php the_ID(); ?>" <?php post_class('show-post-single'); /* class */ ?>>

	


	<?php 
		if( is_home()) { 
			echo  '<h1 class="entry-title">' . '<a href="' . get_the_permalink(). '">' . get_the_title() . '</a>' . '</h1>';

		} else {
			// is_page is_post

			$show_title = get_post_meta( $post->ID, 'show_title',  true ) ? get_post_meta( $post->ID, 'show_title',  true ) : "show";
			$align_title = get_post_meta( $post->ID, 'align_title',  true ) ? get_post_meta( $post->ID, 'align_title',  true ) : "left";

			$show_after_before_text = get_post_meta( $post->ID, 'show_after_before_text',  true ) ? get_post_meta( $post->ID, 'show_after_before_text',  true ) : "no";
			$align_before_after_text = get_post_meta( $post->ID, 'align_before_after_text',  true ) ? get_post_meta( $post->ID, 'align_before_after_text',  true ) : "left";
			$text_before_after_text = get_post_meta( $post->ID, 'text_before_after_text',  true ) ? get_post_meta( $post->ID, 'text_before_after_text',  true ) : "";



			echo  '<h1 class="entry-title '.( ($show_title!="show")? "hidden" : "" ).'" style="text-align:'.$align_title.'">';

			if ( $show_after_before_text == "show" && $align_before_after_text == "left" ){
				echo  '<span class="p-mr-5">' . $text_before_after_text  . "</span>" ;
			}

			the_title();

			if ( $show_after_before_text == "show" && $align_before_after_text == "right" ){
				echo  '<span class="p-ml-5">' . $text_before_after_text  . "</span>" ;
			}

			echo '</h1>';
		}
	?>



	<?php if( !is_cart() && !is_checkout() && !is_account_page() ) { ?>
	<div class="entry-on">
		<span>
		<i class="fa fa-clock-o" aria-hidden="true"></i>
		<?php if(get_the_modified_date('H:i - d/m/Y') == get_the_date('H:i - d/m/Y') ) {
			 	echo get_the_date('H:i - d/m/Y');
			  }	else{  
			  	printf( __('Change: %1$s','ptheme'), get_the_modified_date('H:i - d/m/Y') );
			  } 
		?>
		</span>
		
		<?php if( has_category()) { ?> 
		<span>
			<?php _e(' - Category: ','ptheme') ?>
			<?php the_category(', '); ?> 
		</span>
		<?php } ?>

		<span>
			<?php _e(' - Author: ', 'ptheme') ?>
			<?php the_author_posts_link(); ?> 
		</span>
		
		<?php if( is_single()) { ?> 
		<span>
			<?php _e(' - Views: ', 'ptheme') ?>
			<?php ptheme_view_post() ?> 
		</span>
		<?php } ?>

		<span>
		   <?php edit_post_link( __('Edit post','ptheme'),'- ',''); ?>
		</span>
	</div>

	<?php } ?>

	<div class="entry-content">
		 <div class="clearfix"></div>
		 	<?php the_content() ?>
		 <div class="clearfix"></div>
	</div><div class="clearfix"></div>
	
	<?php if(has_tag()){ ?>
	<div class="entry-tag">
        <i class="fa fa-tags" aria-hidden="true"></i> 
        <?php _e('More Tag: ','ptheme') ?> 
        <?php the_tags('', ' '); ?>
	</div><div class="clearfix"></div>
	<?php } ?> 


	<?php if( is_singular( array("post","page" )) && (!ptheme_is_woocomerce_activated() || (!is_woocommerce() && !is_cart() && !is_checkout() && !is_account_page())))  { ?>

	<div class="entry-author p-mt-30">
		<div class="entry-author-title">Author </div>
		
		<div class="">
			<div class="entry-author-avatar">
			<?php echo get_avatar('', $size = 96) ?>
			</div>

			<div class="entry-author-name">
			<?php the_author_posts_link() ?> 
			- <span><?php printf( __('%1$s Posts','ptheme'),get_the_author_posts()); ?><span>
				
			</div>
	
			<div class="entry-author-des">
				<?php the_author_description() ?>
			</div>
		</div>
	</div>

	 <?php } ?>
	
	
	<!-- next/prev link -->
	<?php if( !ptheme_is_woocomerce_activated() || (!is_woocommerce() && !is_cart() && !is_checkout() && !is_account_page()) ) { ?>
	<div class="entry-next-link row">
		 <?php if( get_previous_post() ){ ?>
		<div class="col-sm-6 p767-t-c prev-post p767-mb-10">
			<div class="meta-nav" aria-hidden="true"><i class="fa fa-angle-left" aria-hidden="true"></i> <?php _e('Previous','ptheme') ?></div>
			<?php previous_post_link( '%link', _x( ' %title', 'Previous post link', 'ptheme' ) ); ?>
		</div>
		<?php } else { ?>
		<div class="col-sm-6"></div>
		<?php } ?>

		<?php if( get_next_post() ){ ?>
		<div class="col-sm-6 p767-t-c next-post p-t-r">
			<div class="meta-nav" aria-hidden="true"><?php _e('Next','ptheme') ?> <i class="fa fa-angle-right" aria-hidden="true"></i></div>
			<?php next_post_link( '%link', _x( '%title ', 'Next post link', 'ptheme' ) ); ?>
		</div>
		<?php } ?>
	</div><div class="clearfix"></div>
	<?php } ?>
	

	<!-- related post -->
	<?php include "related.php"; ?>

<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

