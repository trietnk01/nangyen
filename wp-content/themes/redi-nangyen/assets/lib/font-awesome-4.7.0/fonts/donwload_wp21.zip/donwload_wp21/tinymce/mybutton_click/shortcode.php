<?php
add_shortcode( 'shortcode_mybutton_click' , 'shortcode_mybutton_click' );

function shortcode_mybutton_click($atts){
    return "<hr/>";

}



