<script type="text/javascript">
    var tinyMCE_mybutton_add = <?php echo json_encode(
        array(
            'button_name' => __('mybutton_add', 'ptheme'),
            'tooltip' => __("Hr","ptheme"),
            'image_button_title' => __('Upload image', 'ptheme'),
           // 'image_url' => "https://snwatches.com/image/cache/catalog/icon-280x150.png",
            'shortcode' => "shortcode_mybutton_add",
        )
        );
    ?>;


    jQuery(function($) {
        $('.button-submit-add-data').click(function(){

            // click hide popup thickbox
            $('.thickbox-loading .tb-close-icon').click();

            // lấy data 
            var blogname = $('.form-table-thickbox [name="blogname"]').val();
            var blogemail = $('.form-table-thickbox [name="blogemail"]').val();
            var blogphone = $('.form-table-thickbox [name="blogphone"]').val();

            // reset
            $('.form-table-thickbox [name="blogname"]').val('');
            $('.form-table-thickbox [name="blogemail"]').val('');
            $('.form-table-thickbox [name="blogphone"]').val('');

            // Khỏi check trống hay ko? Cho add vào shortcode hết luôn ,nếu mà rỗng thì sẽ show rỗng luôn
            var shortcode = "[shortcode_mybutton_add " + 
                            ' blogname="'+ blogname +'"' + 
                            ' blogemail="'+ blogemail +'"' + 
                            ' blogphone="'+ blogphone +'"' + 
                            "]";

            // send to tinymce add data
            window.parent.send_to_editor(shortcode);
            window.parent.tb_remove(); 
        })

    });


</script>

<?php 
add_thickbox();
?>

<!-- ** id class -->
<a href="#TB_inline?width=400&height=400&inlineId=mybutton_add_thickbox_content" title="<?php _e("Add text demo","ptheme")?>" class="thickbox" id="mybutton_add_thickbox"></a>   

<div id="mybutton_add_thickbox_content" style="display:none;">

    <div>
        
        <table class="form-table form-table-thickbox"><!-- * class form -->
            <tbody>

                <tr>
                    <th scope="row"><label for="blogname"><?php _e("Name","ptheme")?></label></th>
                    <td><input name="blogname" type="text" id="blogname" value="" class="regular-text"></td>
                </tr>

                <tr>
                    <th scope="row"><label for="blogemail"><?php _e("Email","ptheme")?></label></th>
                    <td><input name="blogemail" type="text" id="blogemail" value="" class="regular-text"></td>
                </tr>


                <tr>
                    <th scope="row"><label for="blogphone"><?php _e("Phone","ptheme")?></label></th>
                    <td><input name="blogphone" type="text" id="blogphone" value="" class="regular-text"></td>
                </tr>


             </tbody> 
        </table>

        <!-- * class submit -->
        <p class="submit"><input type="button" class="button button-primary button-submit-add-data" value="<?php _e("Submit","ptheme")?>"></p>

    </div>

</div>
