<script type="text/javascript">
    var tinyMCE_mybutton_faicon = <?php echo json_encode(
        array(
            'button_name' => __('mybutton_faicon', 'ptheme'),
            'tooltip' => __("Add fa fa icon","ptheme"),
            'image_button_title' => __('Add fa fa icon', 'ptheme'),
           // 'image_url' => "https://snwatches.com/image/cache/catalog/icon-280x150.png",
            'shortcode' => "shortcode_mybutton_faicon",
        )
        );
    ?>;


    jQuery(function($) {

        $('.div-fafa-show-faicon_thickbox>div').click(function(){
            $('.div-fafa-show-faicon_thickbox>div.active').removeClass('active');
             $(this).addClass('active');        
        })

        $('.button_mybutton_faicon_thickbox').click(function(){

            if ( !$('.div-fafa-show-faicon_thickbox>div').hasClass('active')  ) {
                return;
            } else {
                var class_faicon = $('.div-fafa-show-faicon_thickbox>div.active>i').attr('class');   
            }

        
            // Khỏi check trống hay ko? Cho add vào shortcode hết luôn ,nếu mà rỗng thì sẽ show rỗng luôn
            var shortcode = "[shortcode_mybutton_faicon " + 
                            ' class="'+ class_faicon +'"' + 
                          
                            "]";

            // send to tinymce add data
            window.parent.send_to_editor(shortcode);
            window.parent.tb_remove(); 

        })



    });


</script>

<?php 
add_thickbox();
?>

<!-- ** id class -->
<a href="#TB_inline?width=400&height=400&inlineId=mybutton_faicon_thickbox_content" title="<?php _e("Add text demo","ptheme")?>" class="thickbox" id="mybutton_faicon_thickbox"></a>   

<div id="mybutton_faicon_thickbox_content" style="display:none;">

    <div>

         <p style="text-align:center">
            <span class="button button-primary button_mybutton_faicon_thickbox">
                <?php _e("SUBMIT","ptheme")?>
            </span>
        </p>

        <div class="div-fafa-show-faicon_thickbox">
            <?php include "fa-icon.php"; ?>
        </div>

    </div>

</div>




<style>
    .div-fafa-show-faicon_thickbox{
        text-align: center;
        margin: 50px 0px 100px 0px;
    }

    .div-fafa-show-faicon_thickbox>div{
        display: inline-block;
        width: 50px;
        height: 50px;
        line-height: 50px;
        text-align: center;
        border:1px solid #ccc;
        margin:2px;
        cursor: pointer;
        font-size: 20px;
    }


    .div-fafa-show-faicon_thickbox>div:hover{
        background: #fafafa;
    }

    .div-fafa-show-faicon_thickbox>div.active{
        border-color: #008ec2;
        background: #ccc;
    }

    .button_before_after_text{
        padding:10px !important;
        font-size: 15px !important;
        display: inline-block !important;
        width: 100% !important;
        height: 50px !important;
    }

    #TB_window{
        overflow: hidden !important;
    }

    #TB_ajaxContent{
        width: 100% !important;
        height: 100% !important;
        box-sizing: border-box !important;
    }
</style>