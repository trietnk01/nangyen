jQuery(function($) {
    tinymce.PluginManager.add('mybutton_faicon',function( editor, url ){

        editor.addButton( "mybutton_faicon", {
            text: '<fa fa icon>',
            image : tinyMCE_mybutton_faicon.image_url ,
            tooltip: tinyMCE_mybutton_faicon.tooltip,
            onclick: function(){
                $('#mybutton_faicon_thickbox').click(); // target link thickbox
                // var shortcode = "[shortcode_mybutton_faicon]";
                //window.parent.send_to_editor(shortcode);
                //window.parent.tb_remove();
            },
        });
    });
})

