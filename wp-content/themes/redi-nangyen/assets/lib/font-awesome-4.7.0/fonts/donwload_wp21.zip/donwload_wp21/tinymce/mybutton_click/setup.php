<script type="text/javascript">
    var tinyMCE_mybutton_click = <?php echo json_encode(
        array(
            'button_name' => __('mybutton_click', 'ptheme'),
            'tooltip' => __("Hr","ptheme"),
            'image_button_title' => __('Upload image', 'ptheme'),
           // 'image_url' => "https://snwatches.com/image/cache/catalog/icon-280x150.png",
            'shortcode' => "shortcode_mybutton_click",
        )
        );
    ?>;
</script>