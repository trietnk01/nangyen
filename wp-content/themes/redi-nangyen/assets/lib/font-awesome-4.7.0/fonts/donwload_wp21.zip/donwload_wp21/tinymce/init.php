<?php 
// require_once trailingslashit( get_template_directory() ) . 'tinymce/init.php';

// final class
final class Demo_tinymce{

    // add name button tinymce
    public $arr = array("mybutton_click","mybutton_add","mybutton_faicon");
   

    // hook init: 
    public  function mytheme_theme_setup() {
        add_action( 'init', array($this,'mytheme_buttons'));
    }

    // setup 
    public function __construct(){
        add_action('after_setup_theme', array($this, 'mytheme_theme_setup') );
        add_action ('after_wp_tiny_mce', array($this,"mytheme_tinyce_extra_vars") );

        $this->mytheme_shortcode(); // add shortcode -> include file
    }

    // page/post
    public function mytheme_buttons() {

        // Xác định nếu mà edit 1 custom post type nào đó thì return; vd: prodcts
       // if(  current_user_can( 'edit_products' )) return;

         if ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {
            return;
        }
        if ( get_user_option( 'rich_editing' ) !== 'true' ) {
            return;
        }

        add_filter( 'mce_external_plugins', array($this,'mytheme_add_buttons') );

        add_filter( 'mce_buttons_3' ,  array($this,'mytheme_register_buttons') );
    } 

    // add js 
    public function mytheme_add_buttons($plugin_array){
        foreach( $this->arr as $key => $fun ){
        $plugin_array[$fun] = get_template_directory_uri(). '/tinymce/' . $fun . '/insert.js';
        }
        return $plugin_array;
    }




    // resiger button
    public function mytheme_register_buttons($buttons){
        foreach( $this->arr as $key => $fun ){
            array_push( $buttons , $fun );
        }
        return $buttons;
    }



    // add php name/title/img
    public function mytheme_tinyce_extra_vars(){ 
        foreach( $this->arr as $key => $fun ){
            $file =  dirname(__FILE__) . '/'.  $fun  . '/setup.php';
            if(file_exists($file)){
                include $file;
            }
        }   
    }

    // add shortcode
    public function mytheme_shortcode(){
         foreach( $this->arr as $key => $fun ){
            $file_shortcode = dirname(__FILE__) . '/' .  $fun .  '/shortcode.php';
            if(file_exists($file_shortcode)){
                include $file_shortcode;
            }
        }    
    }
}

return new Demo_tinymce(); 